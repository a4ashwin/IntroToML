from pandas import DataFrame
from pandas import read_csv
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn import tree
from numpy import mean
from numpy import cov
from numpy.linalg import eig
from random import random
from random import randint
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import balanced_accuracy_score

#Loading Iris Data
url = "C:\Stuff\KU Study\EECS 690 Intro to Machine Learning\Assignments\AshwinRathore_Assignment5\imbalanced iris.csv"
names = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
dataset = read_csv(url, names=names)
dataset=dataset.drop([0])
#Part 1
array=dataset.values
X=array[:,0:4]
y=array[:,4]


model= MLPClassifier(max_iter=800)
X_train, X_validation, Y_train, Y_validation = train_test_split(X, y, test_size=0.5, random_state=1)
model.fit(X_train, Y_train)
predictions = model.predict(X_validation)
model.fit(X_validation,Y_validation)
predictions=np.append(predictions,model.predict(X_train))
Y_validation=np.append(Y_validation,Y_train)
print("Part 1:")
print("Using Imbalanced dataset")
print("Accuracy:", accuracy_score(Y_validation, predictions))
print("Confusion matrix:")
c=confusion_matrix(Y_validation, predictions)
print(c)
print()

total=0
for i in range(3):
    p= c[i][i]/(c[i][0] + c[i][1] + c[i][2])
    r= c[i][i]/(c[0][i] + c[1][i] + c[2][i])
    if(p<r):
        total+=p
    else:
        total+=r
print("Class Balanced Accuracy: ", total/3)

print()
total=0
for i in range(3):
    m=0
    n=0
    for j in range(3):
        if j==i:
            continue
        for k in range(3):
            if i==k:
                continue
            m+=c[j][k]
    n+=m
    for j in range(3):
        if j==i:
            continue
        n+=c[i][j]
    r= c[i][i]/(c[0][i] + c[1][i] + c[2][i])
    total += (r+(m/n))/2
print("Balanced Accuracy: ", total/3)
print()
print("Skikit-learn's balanced_accuracy_score", balanced_accuracy_score(Y_validation, predictions))

print()
print("======================================================================")
print()
print("Part 2: Over Sampling")


from imblearn.over_sampling import RandomOverSampler
from imblearn.over_sampling import SMOTE, ADASYN
ros = RandomOverSampler(random_state=0)
X_resampled, y_resampled = ros.fit_resample(X, y)
X_train, X_validation, Y_train, Y_validation = train_test_split(X_resampled, y_resampled, test_size=0.5, random_state=1)
model= MLPClassifier(max_iter=800)
model.fit(X_train, Y_train)
predictions = model.predict(X_validation)
model.fit(X_validation,Y_validation)
predictions=np.append(predictions,model.predict(X_train))
Y_validation=np.append(Y_validation,Y_train)
print()
print("Using Random Oversampling: ")
print("Accuracy:", accuracy_score(Y_validation, predictions))
print("Confusion matrix:")
print(confusion_matrix(Y_validation, predictions))
print()

smo = SMOTE()
X_resampled, y_resampled = smo.fit_resample(X, y)
X_train, X_validation, Y_train, Y_validation = train_test_split(X_resampled, y_resampled, test_size=0.5, random_state=1)
model= MLPClassifier(max_iter=800)
model.fit(X_train, Y_train)
predictions = model.predict(X_validation)
model.fit(X_validation,Y_validation)
predictions=np.append(predictions,model.predict(X_train))
Y_validation=np.append(Y_validation,Y_train)
print("Using SMOTE: ")
print("Accuracy:", accuracy_score(Y_validation, predictions))
print("Confusion matrix:")
print(confusion_matrix(Y_validation, predictions))
print()


adasyn = ADASYN()
print("Using ADASYN: ")
try:
    X_resampled, y_resampled = adasyn.fit_resample(X, y)
    X_train, X_validation, Y_train, Y_validation = train_test_split(X_resampled, y_resampled, test_size=0.5, random_state=1)
    model= MLPClassifier(max_iter=800)
    model.fit(X_train, Y_train)
    predictions = model.predict(X_validation)
    model.fit(X_validation,Y_validation)
    predictions=np.append(predictions,model.predict(X_train))
    Y_validation=np.append(Y_validation,Y_train)
    print("Accuracy:", accuracy_score(Y_validation, predictions))
    print("Confusion matrix:")
    print(confusion_matrix(Y_validation, predictions))
except Exception as e:
    print(e)
print()
print("======================================================================")
print()
print("Part 3: Under Sampling")


from imblearn.under_sampling import RandomUnderSampler
from imblearn.under_sampling import ClusterCentroids
from imblearn.under_sampling import TomekLinks

rus = RandomUnderSampler(random_state=0)
X_resampled, y_resampled = rus.fit_resample(X, y)
X_train, X_validation, Y_train, Y_validation = train_test_split(X_resampled, y_resampled, test_size=0.5, random_state=1)
model= MLPClassifier(max_iter=800)
model.fit(X_train, Y_train)
predictions = model.predict(X_validation)
model.fit(X_validation,Y_validation)
predictions=np.append(predictions,model.predict(X_train))
Y_validation=np.append(Y_validation,Y_train)
print("Using Random undersampling: ")
print("Accuracy:", accuracy_score(Y_validation, predictions))
print("Confusion matrix:")
print(confusion_matrix(Y_validation, predictions))
print()

cc = ClusterCentroids(random_state=0)
X_resampled, y_resampled = cc.fit_resample(X, y)
X_train, X_validation, Y_train, Y_validation = train_test_split(X_resampled, y_resampled, test_size=0.5, random_state=1)
model= MLPClassifier(max_iter=800)
model.fit(X_train, Y_train)
predictions = model.predict(X_validation)
model.fit(X_validation,Y_validation)
predictions=np.append(predictions,model.predict(X_train))
Y_validation=np.append(Y_validation,Y_train)
print("Using Cluster undersampling: ")
print("Accuracy:", accuracy_score(Y_validation, predictions))
print("Confusion matrix:")
print(confusion_matrix(Y_validation, predictions))
print()

tl = TomekLinks()
X_resampled, y_resampled = tl.fit_resample(X, y)
X_train, X_validation, Y_train, Y_validation = train_test_split(X_resampled, y_resampled, test_size=0.5, random_state=1)
model= MLPClassifier(max_iter=1000)
model.fit(X_train, Y_train)
predictions = model.predict(X_validation)
model.fit(X_validation,Y_validation)
predictions=np.append(predictions,model.predict(X_train))
Y_validation=np.append(Y_validation,Y_train)
print("Using Tomek Links undersampling: ")
print("Accuracy:", accuracy_score(Y_validation, predictions))
print("Confusion matrix:")
print(confusion_matrix(Y_validation, predictions))
print()

